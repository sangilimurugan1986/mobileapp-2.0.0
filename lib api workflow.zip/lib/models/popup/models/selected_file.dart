class SelectedFile {
  SelectedFile({
    required this.name,
    required this.size,
    required this.type,
    required this.file,
  });
  final String name;
  final String size;
  final String type;
  final dynamic file;
}
