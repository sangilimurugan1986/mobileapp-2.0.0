class Language {
  final String? name;
  final String? shortName;
  final String? image;
  final int? id;

  Language({this.name, this.shortName, this.image, this.id});
}
