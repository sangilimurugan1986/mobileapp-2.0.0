import '../model/Panel.dart';

abstract class WorkflowRepo {
  Future<dynamic> getData();
}
