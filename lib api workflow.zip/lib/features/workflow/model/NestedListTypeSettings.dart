class NestedListTypeSettings {
  NestedListTypeSettings();

  factory NestedListTypeSettings.fromJson(Map<String, dynamic> json) {
    return NestedListTypeSettings();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    return data;
  }
}
