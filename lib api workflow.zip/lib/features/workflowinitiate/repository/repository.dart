abstract class WorkflowInitiateRepo {
  Future<dynamic> getData(String sFormId);
  Future<dynamic> convertJsonStringtoObject(String jsonString);
}
