enum NoduleType {
  Repository,
  Folder,
  File,
}
