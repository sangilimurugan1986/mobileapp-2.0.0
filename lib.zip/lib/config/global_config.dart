const GLOBAL_URL = "https://cloud.ezofis.com/";
const GLOBAL_FILE_URL = "https://cloud.ezofis.com/uploads/";
const APP_NAME = "EZOFIS V5";
const DEFAULT_LANG = "en";
