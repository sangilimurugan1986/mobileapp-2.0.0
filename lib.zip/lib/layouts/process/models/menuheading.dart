import 'package:flutter/cupertino.dart';

class MenuHeading {
  MenuHeading({
    required this.label,
  });
  String label;
}
