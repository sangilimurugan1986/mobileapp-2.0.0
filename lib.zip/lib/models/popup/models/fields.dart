class Fields {
  Fields({required this.label, required this.datavalue});
  String label;
  String datavalue;
}
