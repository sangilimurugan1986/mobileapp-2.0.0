class NestedListTypeSettingsX {
  NestedListTypeSettingsX();

  factory NestedListTypeSettingsX.fromJson(Map<String, dynamic> json) {
    return NestedListTypeSettingsX();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    return data;
  }
}
