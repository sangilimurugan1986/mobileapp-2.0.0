class MatrixTypeSettingsX {
  MatrixTypeSettingsX();

  factory MatrixTypeSettingsX.fromJson(Map<String, dynamic> json) {
    return MatrixTypeSettingsX();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    return data;
  }
}
