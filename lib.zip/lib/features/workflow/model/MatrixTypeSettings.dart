class MatrixTypeSettings {
  MatrixTypeSettings();

  factory MatrixTypeSettings.fromJson(Map<String, dynamic> json) {
    return MatrixTypeSettings();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    return data;
  }
}
