abstract class WorkflowInitiateRepo {
  Future<dynamic> getData();
  Future<dynamic> convertJsonStringtoObject(String jsonString);
}
