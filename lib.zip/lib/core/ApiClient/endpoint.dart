class EndPoint {
  //:- Api Urls
  static const BaseUrl = "http://52.172.32.88/CoreAPI/api/";

  //:- method endpoints
  static const login = "authentication/login";
  static const getuserDetails = "authentication/userSession";
}
