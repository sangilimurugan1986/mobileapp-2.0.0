import 'package:get/get.dart';

class LocalStorage extends GetxController {}
